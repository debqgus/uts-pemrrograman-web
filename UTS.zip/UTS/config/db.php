<?php 
include $_SERVER['DOCUMENT_ROOT'].'/config/variable.php';
$conn = mysqli_connect($config['hostname'], $config['username'], $config['password'], $config['database'])
?>