<?php
include $_SERVER['DOCUMENT_ROOT'] . '/controller/process.php';
if (isset($_POST['submit'])) {
    if (insert('todo', $_POST) > 0) {
        echo "<script>alert('Data berhasil ditambahkan!');location.href='./index.php'</script>";
    } else {
        echo "<script>alert('Data gagal ditambahkan!');location.href='./index.php'</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body align="center">
    <form action="" method="post">
        <label for="">Task : </label>
        <textarea name="task" required id="task"></textarea>
        <br>
        <br>
        <label for="">Penting : </label>
        <select name="penting" required id="penting">
            <option value="tidak">Tdak</option>
            <option value="ya">Ya</option>
        </select>
        <br>
        <br>
        <label for="status">Status : </label>
        <select name="status" required id="status">
            <option value="belum selesai">Belum Selesai</option>
            <option value="selesai">Selesai</option>
        </select>
        <br>
        <br>
        <label for="tanggal_mulai">Tanggal mulai</label>
        <input type="date" required name="tanggal_mulai" id="tanggal_mulai">
        <br>
        <br>
        <label for="tanggal_selesai">Tanggal selesai</label>
        <input type="date" required name="tanggal_selesai" id="tanggal_selesai">
        <br>
        <br>
        <button type="submit" name="submit" value="submit">Submit</button>
    </form>
</body>

</html>