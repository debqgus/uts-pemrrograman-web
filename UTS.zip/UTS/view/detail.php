<?php
include $_SERVER['DOCUMENT_ROOT'].'/controller/process.php';
$id = htmlspecialchars($_GET['id']);
$todolis = get_data('todo', "WHERE id = $id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body align="center">
    <div>
        <p>Tugas : <?=$todolis['task']?></p>
        <p>Penting : <?=$todolis['penting']?></p>
        <p>Status : <?=$todolis['status']?></p>
        <p>Tanggal mulai : <?=$todolis['tanggal_mulai']?></p>
        <p>Tanggal_selesai : <?=$todolis['tanggal_selesai']?></p>
        <p></p>
    </div>
</body>
</html>