<?php 
include $_SERVER['DOCUMENT_ROOT'].'/controller/process.php';
$todolist = get_all_data('todo');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>

<body>

    <br>
    <table class="table" border="1" style="border-collapse:collapse;"
    cellpadding="10" align="center">
    <h1 align="center">TABLE TO DO LIST</h1>
    <thead>
        <tr bgcolor="lightblue">
            <th>NO</th>
            <th>Tugas</th>
            <th>Penting</th>
            <th>Status</th>
            <th>Tanggal Mulai</th>
            <th>tanggal Selesai</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody align="center">
        <?php $no1; foreach ($todolist as $key => $value):?>
        <tr>
            <td scope="row"><?-$no++?></td>
            <td><?=$value['task']?></td>
            <td><?=$value['penting']?></td>
            <td><?=$value['status']?></td>
            <td><?=$value['tanggal_mulai']?></td>
            <td><?=$value['tanggal_selesai']?></td>
            <td><a href="./detail.php?id=<?=$value['id']?>">Detail</a> | <a href="./edit.php?id=<?=$value['id']?>">Edit</a> | <a onclick="return confirm('Apakah ingin Menghapus Data?');"
             href="./delete.php?id=<?=$value['id']?>">Hapus</a></td>
             <tr>
                <?php endforeach;?>
             </tr>
        </tr>
        <tr>
            <th colspan="8" bgcolor="lightgreen"><a href="create.php">Tambah data</a></p></th>
        </tr>
    </tbody>
</table>
</body>
</html>